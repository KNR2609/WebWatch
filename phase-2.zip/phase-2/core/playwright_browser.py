import time
from playwright.sync_api import sync_playwright

class PlaywrightBrowser:
    def capture_screenshot(self, url, path):
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-gpu"
            ])
            
            context = browser.new_context(
                viewport={"width": 1920, "height": 1080},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
                ignore_https_errors=True
            )
            
            page = context.new_page()
            page.add_init_script("delete Object.getPrototypeOf(navigator).webdriver")
            
            try:
                page.goto(url, wait_until="load", timeout=60000)
                time.sleep(8)

                # BREAK CSS LOCKS
                page.evaluate("""() => {
                    const style = document.createElement('style');
                    style.innerHTML = `
                        html, body, #__next, #root, .app-container { 
                            height: auto !important; 
                            overflow: visible !important; 
                            position: relative !important; 
                        }
                        [style*="height: 100vh"] { height: auto !important; }
                        header, .nav, [style*="position: fixed"], [style*="position: sticky"] { 
                            position: absolute !important; 
                        }
                    `;
                    document.head.appendChild(style);
                }""")

                # TRIGGER LAZY LOADING
                for _ in range(8):
                    page.mouse.wheel(0, 1000)
                    time.sleep(0.4)
                
                page.evaluate("window.scrollTo(0, 0)")
                time.sleep(2)

                # CALCULATE HEIGHT
                height = page.evaluate("""() => {
                    return Math.max(
                        document.body.scrollHeight, 
                        document.documentElement.scrollHeight,
                        document.body.offsetHeight, 
                        document.documentElement.offsetHeight
                    );
                }""")

                if height < 100:
                    height = 1080

                page.set_viewport_size({"width": 1920, "height": int(height)})
                time.sleep(2)
                page.screenshot(path=path, full_page=False)
                
            except Exception as e:
                print(f"Error on {url}: {e}")
            finally:
                browser.close()