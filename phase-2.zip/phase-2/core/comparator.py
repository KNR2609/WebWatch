import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim

class ImageComparator:
    def compare(self, base_path, curr_path, diff_path, threshold=0.98):
        img1 = cv2.imread(base_path)
        img2 = cv2.imread(curr_path)

        if img1 is None or img2 is None:
            return False, 0.0

        h1, w1 = img1.shape[:2]
        h2, w2 = img2.shape[:2]
        if h1 != h2 or w1 != w2:
            img2 = cv2.resize(img2, (w1, h1), interpolation=cv2.INTER_AREA)

        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

        score, diff_map = ssim(gray1, gray2, full=True)
        
        if score >= threshold:
            return False, score

        diff_map = (diff_map * 255).astype("uint8")
        thresh = cv2.threshold(diff_map, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
        kernel = np.ones((5, 5), np.uint8)
        thresh = cv2.dilate(thresh, kernel, iterations=2)
        
        # Fixed function name: findContours
        cnts, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        change_count = 0
        for c in cnts:
            if cv2.contourArea(c) > 40:
                change_count += 1
                (x, y, w, h) = cv2.boundingRect(c)
                cv2.rectangle(img2, (x, y), (x + w, y + h), (0, 0, 255), 3)

        if change_count > 0:
            cv2.imwrite(diff_path, img2)
            return True, score
        
        return False, score